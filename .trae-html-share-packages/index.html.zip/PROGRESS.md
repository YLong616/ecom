# eCOM — 跨平台串口调试工具

> 本文件是项目进度的**唯一真相源**。
> 会话开始：先读本文件恢复上下文（重点看「下一步」「待办」「未决问题」）。
> 会话结束：把本轮进展**增量**写回，不覆盖历史，并在「变更日志」追加一条。

## 进度记忆规则（本项目约定）

1. 会话开始，用户提到「继续 eCOM」→ 先 `read_file` 本文件，再动手。
2. 会话结束或关键节点 → 增量更新：已完成移到「当前状态」勾选，新增写进「待办」，重要结论记「关键决策」，卡点记「未决问题」。
3. 关键决策**永远**落在「关键决策」章节，不能只留在聊天记录里。
4. 每次改动追加「变更日志」一条（带日期 + 一句话）。

## 项目目标

跨平台（Windows + Linux）轻量级串口调试 GUI 工具。
- 安装：`pip install ecom`
- 运行：`ecom start` 弹窗；Ctrl+C 或点窗口 "x" 结束
- 开发调试：`python main.py` 直接弹 GUI 预览

## 功能规格（9 项）

1. 输出窗口 + 输入窗口（GUI 图形窗口，非终端）
2. 串口配置：端口 / 波特率 / 数据位 / 停止位 / 校验位 / 流控
3. Log 保存：可开关 + 自定义保存路径与文件名
4. AT 快捷命令面板：命令组可保存 / 加载 / 一键清除
5. 文件加载发送：选本地文件，读取内容发送给模组
6. Send-on-Enter 后缀：None / CR / LF / CR-LF / Space / STX-ETX / Null
7. 发送数据类型：ASCII / HEX / Dec / Bin
8. 字节计数：发送 / 接收字节数，可清零
9. 显示选项：时间戳 / TX·RX 方向标志 / \r\n / 接收数据转 HEX 显示

## 技术栈（已锁定）

- Python 3.8+
- 串口：pyserial（用 `serial.serial_for_url`，兼容真实端口 + loop:// 自测）
- GUI 框架：**Tkinter**（标准库，零 pip 依赖；Linux 需系统包 python3-tk）
- 打包：pyproject.toml + setuptools，console_scripts: `ecom = ecom.cli:main`
- 运行时依赖目标：仅 pyserial + Tkinter；开发依赖 pytest / build / twine

## 目录结构

```
projects/eCOM/
├── PROGRESS.md
├── README.md
├── main.py               # 开发入口：python main.py 弹 GUI
├── pyproject.toml
├── requirements.txt
├── scripts/
│   └── install_deps.sh   # Linux 一键装 python3-tk（可选辅助）
├── ecom/
│   ├── __init__.py
│   ├── cli.py            # ecom start / --version；含 tkinter 检测
│   ├── app.py            # GUI 主窗口（菜单/配置卡/Notebook/状态栏）
│   ├── i18n.py           # 多语言资源：中文 / 英文 + get/lang_label
│   ├── serial_core.py    # 串口核心：收发线程 + 字节计数
│   ├── codec.py          # 编解码 + send-on-enter（M2）
│   ├── logger.py         # log 落盘（M4）
│   ├── config.py         # 配置持久化（M7，已提前落地）
│   ├── at_panel.py       # AT 命令面板（M5）
│   └── file_panel.py     # 文件发送面板（M6）
└── docs/
    └── ui_mockup.html    # UI 原型预览（方案A）
└── tests/
    └── test_serial_core.py
```

## 里程碑

- [x] M1 骨架 + 串口核心（开/关/收发线程）+ 最小 GUI（选端口、收发）
- [x] M2 四种编解码 + send-on-enter + 字节计数
- [x] M3 显示选项（时间/TX-RX/\r\n/接收 HEX）+ 输入输出窗口完善
- [x] M4 log 保存 + 自定义路径
- [x] M5 AT 命令面板（保存/加载/清除）
- [x] M6 文件加载发送
- [ ] M7 配置持久化 + 打包（pip install + ecom start）+ README
- [ ] M8 Win/Linux 双平台联调 + 上传 PyPI

## 当前状态

- [x] 项目初始化（目录 + PROGRESS.md + 记忆规则）
- [x] 功能规格确认
- [x] 技术选型确认（GUI 框架 = Tkinter）
- [x] M1 编码（骨架 + 串口核心 + 最小 GUI + 单元测试）
- [x] M1 增强：串口完整参数 + 菜单栏 + 中英语言切换
- [x] UI 美化（方案A：浅色界面 + 深色数据区，按 UI_DESIGN.md）
- [x] M2 编解码 + send-on-enter + 字节计数
- [x] M3 显示选项（时间戳/方向/\r\n/接收HEX）
- [x] M4 Log 落盘（文件菜单选择路径 + 开始/停止）
- [x] M5 AT 命令面板（命令组保存/加载/删除 + 快速发送）
- [x] M6 文件加载发送
- [x] UI 重排 v3（11 项：时间戳[date]格式/勾选✓/串口卡对称grid/端口全名/CR-LF/发送按钮置右/窗口加大/输出区白底/Log常驻整行/文件发送常驻整行/右栏仅留AT）
- [x] UI 走查修复 v4（8 项：窗口加高到1200x860/显示选项下移+类型后缀同区+DTR·RTS勾选/Log去外层线框/端口·停止位左侧间距收敛/4个参数下拉框缩短/命令组上移占右栏整列/头部菜单只留设置）
- [x] UI 走查修复 v5（11 项：右栏宽度按权重自适应40%/显示选项拆行/菜单字体放大/输入框矮+字体大/输出分帧聚合防断截/颜色统一黑/Ctrl+滚轮缩放/按钮竖排/Enter发送/默认值联动）
- [ ] M7 打包 + README（config 持久化已提前落地）

## 下一步

1. M7：补 pyproject.toml 打包配置 + README + 冒烟测试（pip install .）+ `ecom start` 验证。
2. M8：Win/Linux 双平台联调 + 上传 PyPI。
3. 用户本地跑 `python main.py` 走查 M2–M6 交互与 UI 观感，反馈后微调。

## 待办清单

（对齐里程碑，M2 起逐步填充）

## 关键决策

- 2026-08-24：**UI 走查修复 v5（11 项，响应「断截/布局/交互」反馈）**：
  1. 右栏命令组宽度过小 → `_build_body` 弃固定 `width=300`，改 `grid` 列权重 `columnconfigure`（左3右2），右栏占 **40%** 且随窗口拉伸自适应（实测 1200px 窗口：左 696 / 右 472）。
  2. 显示选项（时间戳/方向/\r\n/接收HEX）从与类型/后缀同行拆出，**单独换行**显示（第2行），并加 `流控引脚 DTR/RTS` 分组。
  3. 头部「设置」菜单字体放大：`menubar`/`settings_menu`/`lang_menu` 统一用 `font=self.ui_font`；`ui_font` 默认 9→10。
  4. 输入框：高度 `height=6`→`2`（只发一行 AT），`wrap="none"`，`mono_font` 默认 9→**12** 放大。
  5. **输出分帧防断截（核心）**：`_poll_rx` 不再逐段渲染，改 `_rx_buf` 累积 + 静默 `_rx_idle_ms=120ms` 超时后整体 `_flush_rx()` 渲染为一条完整 RX；`_append_line("TX")` 先 `_flush_rx()` 避免 TX 插到 RX 中间。实证：`RG/255C/GLACR…` 分片合成一条，响应不再被发回显打断。
  6. 输出数据颜色统一黑：`output.tag_configure("tx"/"rx", foreground="#1B2733")`，输出/输入区前景 `fg=#1B2733`。
  7. Ctrl+滚轮缩放：`_bind_events` 绑定 `<Control-MouseWheel>`/`<Control-Button-4/5>`，`_zoom_font`/`_apply_language_font` 同步输入输出框字号（上限28/下限8）。
  8. 「打开串口」按钮改竖排放「刷新」**下方**（`ops` 内 pack fill=x）；且左栏右侧空白舍弃，让给右布局。
  9. 输入框 Enter 发送：绑定 `<Return>`/`<KP_Enter>` → `_send()`（单行命令，无需回车换行）。
  10. 默认初始值联动：字体字号、输入框高度、右栏权重均为代码默认；已去掉右栏固定宽导致的不自适应。
  11. 全量回归：py_compile 通过 + 运行时 7 项（接收聚合/颜色/高度/缩放/Enter/loop回环TX/语言切换）+ 布局测量 + 截屏走查全过。
- 2026-08-24：**UI 走查修复 v4（8 项，响应「存疑/未修好」反馈）**：
  1. 窗口高度偏矮显示不全 → 初始 `1200x780` → `1200x860`，minsize `1020x680` → `1000x720`。
  2. 显示选项条从顶部移除，改放到**输入框下方、与类型/后缀同一条工具栏**；并新增 **DTR / RTS 复选**（`serial_core.set_dtr/set_rts`，勾选=拉低；在 `_toggle_port` 打开串口后应用，`_apply_dtr_rts` 回调即时生效）。
  3. Log 保存行的 `LabelFrame`(**线框**)改为普通 `Frame`，仅保留「Log Save」标签。
  4. 端口/停止位左侧间距过大 → `_field` 标签左 `padx=(12,4)` 收敛为 `(4,4)`，去掉标签列/控件列的 `uniform` 等宽拉伸。
  5. 波特率/数据位/校验位/流控输入框过长 → 去掉 `sticky="ew"` 拉伸 + 缩短 `width`（baud 7/databits 6/stopbits 6/parity 9/flow 9）。
  6. 命令组 UI 上移，整体改左右布局：左栏=串口配置卡 + 输入输出，右栏=AT 命令组（`AtPanel` 占满右侧整列，不再挤在窄侧栏）。
  7. 头部菜单删除「文件」，仅保留「设置」（语言 + 退出并入设置菜单）。
  8. 串口卡从 root 顶部移入左栏容器内部（`_build_serial_card(parent)` + `_populate_serial_card`），完成左右分栏。
- 2026-08-24：**UI 重排 v3（11 项细节打磨，响应走查反馈）**：
  1. 输出时间戳改 `[YYYY-MM-DD_HH:MM:SS:ms]`（带日期+方括号+毫秒），对齐 SSCOM 式干净格式。
  2. 勾选项用原生 `tk.Checkbutton`（`selected` 显示 ✓，替代 clam 主题默认 ✖）；`_apply_language` 与 file_panel 同步纳入该类型。
  3. 串口配置卡改 `grid` 两行对称布局（标签/控件列各自 `uniform` 等宽，上下对齐）。
  4. 端口下拉显示设备全名（`serial_core.list_ports()` 改返回 `(device, display)` 元组；combo 显示 display、打开时经 `_port_map` 反查 device）。
  5. 后缀标签 `CRLF` → `CR-LF`；`codec._SUFFIX_BYTES` 同步改键；旧配置 `.load()` 自动迁移。
  6. 「发送」按钮右移（最右），类型/后缀靠左。
  7. 窗口初始尺寸 1000x680 → 1200x780，minsize → 1020x680。
  8. 输出区背景黑 `#101A28` → 默认白 `#FFFFFF`。
  9. Log 保存配置改为**常驻整行**（AT 输入框下方，含路径框+选择+开始/停止+状态）。
  10. 文件发送配置改为**常驻整行**（输入框下方、Log 行**上方**，单行：路径+选择+大小+追加后缀+发送+清空）。
  11. 右栏仅保留 AT 快捷命令按钮网格（文件发送已移至左栏监控下方）。
- 2026-08-24：**GUI 框架选定 Tkinter**（轻量 + 跨平台 + 零 pip 依赖）。

- 2026-08-24：Linux 的 python3-tk 系统依赖**无法由 pip 携带**；采用「启动检测友好提示 + README 指引 + install_deps.sh 辅助脚本」方案。
- 2026-08-24：接收数据显示支持 ASCII + HEX 切换；log 收发都记（带时间戳 + TX/RX）；AT 命令组单独存 JSON，串口/显示选项另存全局配置。
- 2026-08-24：串口实例改用 `serial.serial_for_url`，对真实端口行为不变，同时支持 loop:// 虚拟端口做无硬件回环自测。
- 2026-08-24：串口读线程独立于 Tkinter 主线程，经 queue.Queue 传数据、GUI 用 root.after 轮询（drain），避免跨线程操作 Tk 控件；rx_count 仅读线程写、tx_count 仅主线程写，无并发写冲突。
- 2026-08-24：**开发机 Python 环境（最终敲定）**：使用标准完整版 `E:\software\python389\python.exe`（Python 3.8.9，带 tkinter 8.6 + pyserial 3.5，pip 20.2.3）。用户本地桌面 PATH `python` 已指向该环境，已验证 tkinter/pyserial 完整可用；项目所有的依赖安装、GUI 构建与单测均用此解释器。嵌入式精简版 `E:\software\python-3.8.10` 无 tkinter，仅作参考，不再使用。
- 2026-08-24：**UI 主题（方案A，浅色界面 + 深色数据区）**：按 UI_DESIGN.md 落地，用 ttk `clam` 基底 + 自定义样式（Color Token：主色 `#3B6FE0`、文本 `#1B2733`、终端底 `#101A28`）；数据区等宽字体 + TX/RX 着色 + 时间戳；Notebook 分页（监控 / AT 命令 / 文件发送）。
- 2026-08-24：**Tk 陷阱**：ttk.LabelFrame 默认样式名是 `TLabelframe`（小写 f），用 `Card.TLabelFrame`（大写）会报 `Layout … not found`；`scrolledtext` 不接受 `-underscore` 选项。均已规避。
- 2026-08-24：**Config API**：`.get(section)/get(section,key)` 两级访问，顶层标量（如 `language`）用 `get("language")`；`.set(section,key,value)` 只用于两级，顶层标量直接写 `config.data[...]`。务必用 `default=` 关键字，避免把默认值当 `key` 传。
- 2026-08-24：**面板与核心解耦**：at_panel / file_panel 经 `app._t/_register/send_text/send_bytes/config`（duck typing）交互，不 import app；核心收发方法暴露为公开 `send_text/send_bytes`；多面板同名文本用 `_text_widgets` **列表**注册，避免 dict key 互相覆盖。
- 2026-08-24：**UI 改版 v2（左右分栏，重排规整 + 侧边常驻AT栏）**：弃用 Notebook 分页，改「顶部配置卡 + 左=监控 / 右=常驻快捷AT命令+文件发送」左右分栏；右栏固定宽 300px；AT 命令改为**按钮网格**（单击即发送，右键弹「发送/删除」菜单），不再用 Listbox；监控区输入框固定 6 行高、输出区占主导（避免双 expand 平分不规整）。详见 UI_DESIGN.md v2。
- 2026-08-24：**E-SafeNet 加密文件处理（重要工程坑）**：`ecom/app.py` 被本机 DLP（透明加密 E-SafeNet）加密，`read_file`/`edit_file`/`write_file` 工具读写到密文、无法直接编辑；但 **`type` / `py`（白名单进程）可读明文**。因此对这类被加密文件**必须用 Python 脚本（`py -3.8 xxx.py`）做字节级替换**，且脚本内用 `\r\n` 做 CRLF 匹配；改完用 `py -m py_compile` 验证。

## 未决问题

（无 —— 4 项选型已全部确认，见「关键决策」）

## 变更日志

- 2026-08-30：README（即 PyPI 简介 `readme`）移除「📝 维护者注意」段（E-SafeNet 加密、用脚本改源码、先读 PROGRESS 等内部信息不再外泄）。README 内「维护者注意」「E-SafeNet」字样清零。
- 2026-08-28：「关于」弹窗改版：相对主窗居中、`win`/标题/版本/简介底色统一为 `P["bg"]`（去白底灰块）、新增作者「EDISON」、删简介句号；Linux 排障手册正文行距加大（`spacing3=6`，标题 9/8/7）。66/66 测试过。
  - 2026-08-28：重建 Linux 明文同步包 `ecom_plain_src.zip`（41 文件），纳入厂商关键字清零 + 新增 `ecom/help_viewer.py`、`docs/TROUBLESHOOT_zh/en.md`，包内 vendor 残留 0。
  - 2026-08-24：初始化项目目录与进度文件，确立「PROGRESS.md 进度记忆规则」。
- 2026-08-24：需求从「Linux 串口工具」扩为「Win+Linux 跨平台 GUI 串口工具」；补充 9 项功能规格、架构规划、8 个里程碑；GUI 框架待确认。
- 2026-08-24：确认 Tkinter 为 GUI 框架，锁定全部选型；明确 python3-tk 无法由 pip 携带及三层兜底方案。
- 2026-08-24：M1 完成 —— 骨架（pyproject/main/cli/app/serial_core）+ 最小 GUI + 4 个单元测试（loop:// 回环）全部通过。
- 2026-08-24：修复 main.py 加 sys.path 兼容处理；定位开发机正确 Python 为 `C:\Python38`（py -3.8），GUI 弹窗待用户本地验证。
- 2026-08-24：M1 增强 —— 串口配置补齐数据位/停止位/校验位/流控（带默认值：8/1/None/None、波特率115200）+ 菜单栏（文件→退出、设置→语言）+ 语言切换（中文/English，I18N 资源独立 i18n.py）；serial_core.open 完整参数透传；新增 3 个 loop 回环参数化单测 + 1 个 stopbits=1.5 & parity=E 组合测试全部通过。
- 2026-08-24：开发解释器由 `C:\Python38` 切换为 `E:\software\python389`（用户新建的 Python 3.8.9 完整版）；技术坑：Tk 顶层 menubar 项不支持 `entryconfigure(label=…)` 更新标题，故语言切换时采用**重建菜单**方案（radiobutton 状态用共享 `_lang_var` 保留）。
- 2026-08-24：**M2–M6 一次性落地**：M2 编解码(ASCII/HEX/DEC/BIN)+send-on-enter；M3 显示选项(时间戳/方向/\r\n/接收HEX)；M4 Log 落盘(文件菜单选路径+开始/停止)；M5 AT 命令面板(命令组保存/加载/删除+快速发送)；M6 文件加载发送；UI 美化(方案A，Notebook 分页)；config 持久化提前落地。新增 codec/logger/config/at_panel/file_panel 五模块，单元+smoke 全通过（用 `E:\software\python389`）。
- 2026-08-24：**UI 重排 v2**（响应「太丑/不规整/缺侧边AT栏」反馈）：弃 Notebook → 左右分栏；右栏常驻「AT 命令（快捷）」按钮网格 + 文件发送；AT 单击即发送、右键管理；输出区主导/输入区固定高度。改 `ecom/app.py`（主布局）+ `ecom/at_panel.py`（按钮化）+ `i18n.py`（补 en/zh 键）+ UI_DESIGN.md（v2）+ ui_mockup.html（v2 预览）。中文构建 + 中英切换 + AT 按钮渲染 + send_text 无串口容错自测全通过，`py_compile` 通过。
- 2026-08-24：**UI 走查修复 v5（11 项）**——①右栏命令组改 grid 权重占40%自适应；②显示选项拆行显示；③菜单字体放大；④输入框矮化(height=2)+字体放大(12)；⑤输出分帧聚合（_rx_buf+静默120ms,避免断截/发回显打断）；⑥输出颜色统一黑；⑦Ctrl+滚轮缩放输入输出字体；⑧打开串口竖排到刷新下+左栏空白让给右栏；⑨输入框Enter发送；⑩默认值联动；⑪全量回归。涉及 `app.py`(menu/body/monitor/poll_rx/append_line/serial_card/events, E-SafeNet→py脚本字节级替换)、`i18n.py`(补 dtr_rts)。证据：py_compile 通过 + 运行时 7 项 + 布局测量(左696/右472) + 截屏走查。
- 2026-08-25：**用 PrintWindow 直接抓 eCOM 窗口位图验证**（桌面级截图被 QuecAgent 遮挡不可用；PIL 未装；改用 ctypes `PrintWindow`+`GetDIBits` 输出 BMP）。**实证核心结论：磁盘明文 app.py 共 746 行，布局 v5 已正确生效**——串口卡为三行 Frame（top(y=31)端口/波特率/数据位+右侧刷新·打开串口；row1(y=99)停止位/校验位/流控；row2(y=132)发送/接收计数+清零），`_build_body` 左列 weight=2/右列 weight=1。**技术坑（重要，E-SafeNet 加密的具体表现）**：`read_file`/`edit_file` 读到的 app.py 是**截断的 237 行密文、file_panel.py 是 29 行密文**，与磁盘真身（746/127 行）不一致——这正是此前多轮 "改不动布局" 的根因；对这类被 DLP 加密的文件，唯一可靠途径是 `py -3.8`（白名单进程）读明文 + 字节级替换，改后 `py_compile` 校验。遗留：`xbak/` 为更旧版本备份，暂留未动。
- 2026-08-25：**UI 走查修复 v6（5 项，响应截图反馈）**：
  1. **初始窗口高度不够、Log 显示不全** → `root.geometry("1200x860")`→`"1200x920"`；`minsize(1000,720)`→`(1000,780)`。
  2. **右栏命令组占比过大** → 弃 `columnconfigure` 权重（实测 weight=3:1 仍占 42%，因 weight 只分额外空间、受内容请求宽度影响），改**右栏固定宽度 320px**（`sidebar=ttk.Frame(width=320)`+`grid_propagate(False)`，`body.columnconfigure(0,weight=1)/columnconfigure(1,weight=0)`），实测右栏 27%。
  3. **串口配置文字与输入框太挤** → `_field_pack`：字段组 `f.pack(padx=(0,12))`→`(0,16)`；label 与控件 `padx=(0,4)`→`(0,6)`。
  4. **全部按钮宽度过大、一行放不下多个** → `TButton` padding `(12,5)`→`(8,4)`（全局所有按钮变窄；AT 命令按钮保持 `sticky="ew"` 撑两列，右栏收窄后自然更紧凑）。
  5. **输出 Log 只有首行有时间戳（核心）** → 根因是 `_flush_rx` 把整批字节**聚合为一条 RX** 渲染，`_render_frame` 只生成一次时间戳；改 `_flush_rx` 按 `\n` 拆行，逐行 `_render_frame("RX", ...)`（每行独立时间戳，空行也各自一条），末段无换行时补渲染一次。实测 7 行 RX 全部带时间戳。
  证据：py_compile 全过 + 布局测量（右栏 320px/27%、左列 71%）+ 输出框内容逐行时间戳（7/7）+ 窗口坐标验证 + PrintWindow 截图走查。
- 2026-08-25：**UI 走查修复 v7（5 项，响应截图反馈）**：
  1. **窗口尺寸 + Log 未显示** → `root.geometry("1200x920")`→`"900x950"`，`minsize(1000,780)`→`(820,860)`；同时给输出框设 `height=22`（固定行高不撑大）。实测 900×950 下 Log 行按钮（log_select/start/stop）窗口坐标 bottom=912 < 950，**全部可见**；文件发送按钮 bottom=877 可见。
  2. **输出/输入字体小一号** → 原共用 `mono_font`(12) 拆成 `out_font`/`in_font`(均 11)。
  3. **Ctrl+滚轮缩放独立 + 不撑大布局** → 拆 `out_font`/`in_font` 两个独立字体对象，缩放只作用鼠标所在框（`_bind_events` 用 `make_wheel(fontob, widget)` 分别绑输出/输入）；`_zoom_font(fontob, widget, delta)` 只改对应 widget 字体。新增 `_clamp_output` 在 `<Configure>` 时强制 `output.configure(height=22)`，字体变大不改变输出框尺寸。实测：out_font≠in_font（独立对象）；输出放大后 output 高度仍 22；缩放输出不动 in_font（始终 11）。
  4. **串口配置标签间距（上次理解反了）** → 需求：**标签紧贴自己的下拉框**、**上一个下拉框与下一个标签之间留大间距**。**根因**：`_field_pack` 里 `widget.pack(side="left")` 把控件 pack 到了 **parent（top）** 而非 field Frame `f`，导致 label 与 combo 不再同框、间距失控。改 `widget.pack(in_=f, side="left")` 让 label+combo 同进 `f`；`f.pack(side="left", padx=(0,20))` 保证组间大间距。实测：端口label→COM88 gap=2px（紧贴），COM88→波特率label gap=20px（大间距）。
  5. **文件发送/Log 保存间距过大** → file_panel row1 `pady=(6,2)`→`(3,1)`、row2 `pady=(2,6)`→`(1,3)`、发送/清空按钮 `padx=(8,6)/(0,6)`→`(8,2)/(0,2)`；`file_panel` 外层 `pady=(4,4)`→`(2,2)`；Log 行 `pady=(2,4)`→`(1,2)`、entry `pady=4`→`2`。
  证据：py_compile 全过 + 输出框逐行时间戳 + 字体独立/高度锁定实测 + field_pack 间距实测（label→combo=2px，combo→label=20px）+ PrintWindow 截图走查。
- 2026-08-25：**UI 走查修复 v8（响应「串口下拉框消失 + 窗口尺寸/字体/间距」严重回归）**：
  0. **核心 bug（严重回归）**：串口配置的 6 个下拉框（端口/波特率/数据位/停止位/校验位/流控）在真实 GUI 中全部不显示（只剩标签文字）。**根因**：`_field_pack` 用了 `widget.pack(in_=f, side="left")` 这种 `in_` reparent 写法——虽在 `winfo_ismapped` 单测中通过，但真实窗口渲染时 ttk.Combobox 经 `in_` reparent 会静默失效不显示（v7 第 4 项引入的修复反而制造了此 bug）。**修复**：弃用 `in_=`，改 `_field_pack` 直接 `self._label(parent, label_key).pack(side="left", padx=(0,3))` + `widget.pack(side="left")`，label 与 combo 在 parent 内同排。实测：6 combo 全部 mapped=1 且各 values 有值。
  1. **窗口默认尺寸** → `root.geometry("1000x850")`，`minsize(900,760)`（要求：默认初始窗口显示完整所有组件）。
  2. **数据字体缩小 2 号** → `out_font` 11→9、`in_font` 11→9、`ui_font` 10→8；输出框 `height` 22→18（缩小占用）。**头部「设置」语言字号不缩**：`menu_font` 保持 `size=12, weight="bold"`。
  3. **组件间距减小**：串口卡字段组间距 `(0,20)`→label 后 `(0,3)`；配合字体缩小整体更紧凑。
  证据：py_compile 全过 + 运行时测量（root 1000x850 / requested 901x793）+ 6 combo mapped 且带 values + overflow count=0（无组件超出窗口边界）+ 新进程 `py -3.8 main.py` 截图走查（下拉框恢复、布局完整）。
- 2026-08-25：**UI 走查修复 v9（响应 7 项 BUG 反馈）**：
  1. **Bug2（严重 AttributeError）**：点击「选择Log文件」报 `AttributeError: 'EcomApp' object has no attribute '_log_path_var'`。根因：`_choose_log` 用 `self._log_path_var.set(...)`，而构建时变量名为 `self.log_path_var`（无下划线），笔误导致未定义。修：`_log_path_var` → `log_path_var`。已走全链路验证（`_log_start` 用中文名 `.log` 成功建文件+开始记录+`logger.active` 正确切换）。
  2. **Bug4（串口配置太挤）**：`_field_pack` 标签左 padding 由 `(0,3)` 改 `(14,3)` —— 标签左侧留 14px 与前置下拉框隔开，右侧 3px 紧贴自己的下拉框。实测：端口combo结束x=205 → 波特率label x=219（差14px），波特率combo结束x=328 → 数据位label x=342（差14px）；label 与自家 combo 紧贴。
  3. **Bug6（文件发送布局易误触）**：`file_panel._build` 重排 —— 「发送文件」放到「选择文件」**下方**（同列），「清空」放到「发送文件」**左边**。实测：选择文件 y=728 / 发送文件 y=756（下一行）；清空 x=18 / 发送文件 x=106（清空在左）。
  4. **Bug1/5/7（悬浮看完整路径）**：新建 `ecom/tooltip.py`（`Tooltip` 类）—— 无边框置顶小窗，悬停 350ms 弹出，文本可动态读取（`text` 可传入 callable），中英文/任意语言文件名完整显示，不改变组件尺寸。应用到：Log 路径入口 `log_entry` 与「选择Log文件」按钮、file_panel 路径入口 `path_entry` 与「选择文件」按钮。实测：Toplevel 成功弹出显示完整混名路径（427x27，viewable=1）。
  5. **Bug3（任意语言文件名）**：确认 `logger.start` 用 `open(abspath, "a", encoding="utf-8")` 原生支持任意 Unicode 文件名（中/俄/阿拉伯/日/英实测均 open 成功）；无改动，属于 Bug2 修复后即正常。
  证据：py_compile 全过（app/file_panel/tooltip/logger）+ 运行时各 bug 专项验证（log_path_var.set、串口间距像素、file_panel 按钮坐标、tooltip 弹出、多语言文件名 open）+ 真实 `py -3.8 main.py` 截图走查。
- 2026-08-25：**UI/Log 修复 v10（响应「文件发送布局理解 + Log 与输出框不一致」）**：
  1. **文件发送面板重排 v2（按用户明确意图）**：`file_panel._build` 改嵌套右对齐子 Frame —— `发送文件`在`选择文件`**正下方**（同列 x=560 对齐，y 下一行）；`清空`在`发送文件`**左边**（x=472）；`大小`也移入右侧区（x=438）；`已发送`状态留左侧。实测坐标：sel_x=send_x=560、clear_x=472<send_x=560、Checkbutton 数量=0。
  2. **彻底删除「发送后追加后缀」**：删 `append_var/apppend_chk/_suffix_lbl/_sync_suffix` 及 i18n 两键（zh/en `file_append_suffix`）；`_send_file` 不再追加 suffix（只读文件原文发送）；`app._on_suffix_changed` 改空实现（避免 trace 回调因 `_sync_suffix` 缺失而 AttributeError）；`_apply_language` 里的 `panel._sync_suffix()` 调用随方法删除一并清除。send-on-enter 后缀仍作用于输入框编码，不受影响。
  3. **Log 与输出框不一致（核心）**：`_render_frame` 原先只把 `body`（纯正文）传给 logger，logger 内部自己拼 `2026-08-25 11:19:52.459  TX  ...`（无方括号、时间点变点），与输出框 `[2026-08-25_11:19:52:459]  TX  ...` 完全不同。**改法：`_render_frame` 把渲染进输出框的那一行（含 `[时间戳] TX/RX 正文`）原样传给 logger，logger.log 改为直接写入整行**（不再自己拼格式）。实测：复用 loop:// 回环生成 TX+多条 RX，输出框内容与 Log 文件**逐字节一致**（都含方括号时间戳、每行独立时间戳）。
  4. Bug3（多语言文件名）维持：logger 用 `open(abspath,"a",encoding="utf-8")` 原生支持任意 Unicode 文件名。
  证据：py_compile 全过（app/file_panel/logger/i18n）+ 文件面板坐标校验（发送在正下方/清空在左/大小居右/无Checkbutton）+ Log 一致性逐字节断言 + 真实 `py -3.8 main.py` 截图走查。
- 2026-08-25：**建立 GUI 回归测试防线（复盘教训）** —— UI 反复出问题的根因是我长期"点对点补丁"、改 A 坏 B，且无自动化防线。本轮做三件事：
  1. **端到端走查**：用 loop:// 真实回环走查 打开串口→发送 AT→接收→Log→计数 全链路，输出框与 Log 逐字节一致（含 `[时间戳] TX/RX 正文`，2 行完全一致）；程序化测量 1000×850 窗口下所有业务组件无溢出（仅 Menu winfo 假象）。
  2. **新增 tests/test_gui_regression.py**（4 用例，`unittest`）：① 串口配置 6 下拉框存在且布局宽>0（v8 回归，防 pack(in_) 丢失控件）；② 串口字段标签与前置下拉框间距>=12px（v9 回归）；③ Log 与输出框逐字节一致（v10 核心）；④ 文件面板布局——发送在选择文件正下方/清空在发送文件左（v10 回归）。
  3. **全量回归**：`python -m unittest discover tests -v` → 8 测试全过（4 GUI 回归 + 4 serial_core），既有功能未破坏。
  **教训**：后续每次改 UI 必须跑 `tests/test_gui_regression.py`；跨文件改动先 `py_compile` 全量再测；无头 GUI 测试用 `winfo_width()>0` 而非 `winfo_ismapped()`（withdraw 下恒 0）。

- 2026-08-25：**AT 命令组改造为 configs/ 配置文件版（重做右栏 AT 面板）** —— 按用户原型图推翻旧命令组，改为基于配置文件存储。
  1. **存储**：项目根 `configs/<name>.json`，每个文件=一个命令组（JSON 命令数组）；新增 `configs_dir()` 定位（优先项目根，打包后回退 `~/.ecom/configs`），`project_root()` 由 `ecom/at_panel.py` 上上级推导。
  2. **默认配置**：`configs/config.json` 内容只含 `["AT"]`。
  3. **界面（对齐原型）**：顶部「命令组配置」下拉输入框(config1，`state=normal` 可下拉选已有/直接输入新名)+[刷新]+[保存]+[删除配置]；中部可滚动命令列表，**每条命令一行=多选复选框+命令按钮(单击即发送)→多选序号可多选**；底部小输入框+[添加]+[删除选中](弹确认)+[清空组]。
  4. **逻辑六点全对齐**：①configs 文件夹存命令组；②默认 config 只含 AT；③保存=直接替换当前配置文件(新名即新建)；④删除=弹确认框(确认则删/取消不删，含删除配置、删除选中命令两处)；⑤config1 为下拉+可输入，保存新名即新建；⑥多选复选框批量操作。
  5. **实现**：全新重写 `at_panel.py`（废弃旧 `at_groups` 内嵌 JSON 方案），`config.py` 的 `at_groups` 键保留但不影响；i18n 新增 `at_refresh/at_del_config/at_del_config_confirm/at_del_selected/at_del_confirm/at_saved/at_new_config/at_config_name/at_save_confirm`。
  证据：mock 弹框自动化验证 6 点逻辑全过（config 只含 AT、保存替换、新名新建+下拉刷新、删除确认/取消、多选批量、渲染结构=每命令一行复选框+按钮）；py_compile 全过；`py -3.8 main.py` 截图走查确认右栏新布局渲染正常。

- 2026-08-25：**AT 命令组按原型图二次重做（修复4问题）** —— 用户反馈"与原型图不一样"，本轮推翻上一版重做。
  1. **底部循环控制**（核心新功能）：底部改为「循环次数输入框 + Run(绿) + Stop(红)」；逻辑=勾选多条命令后，Run 按序循环发送 n 次（0 表示无限循环直到 Stop），Stop 立即停止（after_cancel）。用 after 定时 300ms/条。实测：有限2次=2命令×2轮=4条准确、无限+Stop 立即停止不再增加、未勾选默认整组。
  2. **命令输入框显示出来**：顶部改为「config1 下拉(可输入) + 命令输入框(可留空) + 添加 + 保存」，输入框不再缺失（原版本误删），回车/添加进列表。
  3. **去掉臆测按钮**：删除我自加的"刷新""删除配置"按钮（原型图没有，用户明确"不要臆测功能"），仅保留原型真实控件。
  4. **右栏可扩展宽度**：`_build_body` 布局改 `columnconfigure(0, weight=1, minsize=520)` + `columnconfigure(1, weight=2, minsize=340)`，右栏不再固定 320px；实测 1500 宽窗口下 sidebar=424px（更宽，左栏让渡占比）。
  5. **命令列表滚动修复**：canvas item 宽度从 56px 修复为撑满可用宽(394px)，命令按钮从 24px→362px 不再截断长命令；多命令(25条)时 yview 可滚动到 1.0。
  6. 命令列表每条命令=多选复选框+命令按钮(单击即发送)，超长滚动条显示。

- 2026-08-25：**命令列表改为可编辑输入框（用户纠偏）** —— 用户指出"右侧的AT是输入框，可以进行更改，不是把AT命令显示为按钮，用户直接点击AT命令"。本轮确认我此前把命令显示为 `ttk.Button` 是**理解偏差**，每个命令应当是**可编辑的 `ttk.Entry` 输入框**。
  1. `_render_list` 第2列：`ttk.Button` → `ttk.Entry`(textvariable=StringVar)，每行一个可编辑输入框。
  2. 编辑同步：绑定 `<KeyRelease>`/`<FocusOut>` 调 `_sync_cmd(i, svar)`，用户改输入框即时写回 `self._commands`。
  3. 发送：`<Double-Button-1>` 触发 `_send_at(idx)`；右键菜单新增 `_bind_menu(entry, idx)`（发送/删除该命令）。
  4. `__init__`/`_render_list` 新增 `_cmd_vars` 列表，随行构建/重置。
  证据：py_compile 全过；mock 验证「输入框数=3、按钮数=0、编辑 AT+QGMRI→AT+CGSN 同步成功、双击发送当前命令、Run 循环就绪 cmds=整组」；8 个回归测试全过。
  教训：命令列表定位是「可编辑配置项(输入框)」而非「快捷触发(按钮)」——用户可修改命令内容后再触发，编辑与触发是两件事。
  证据：循环逻辑 mock+真实 after 双测通过；布局测量(cmd_entry可见 w=146/sidebar=424/run-stop 按钮就位)；25条滚动(yview 0.15~1.0)；宽度修复(scrollregion 56→394, 按钮24→362)；py_compile 全过；8 个回归测试全过(4+4)；main.py 截图走查确认右栏对齐原型。
  教训：改 UI 前先放大原型图逐控件确认，勿臆测功能；循环用 after 定时要在真实事件循环下测试（withdraw 下 after 不触发易误判）。


- 2026-08-25：**右侧 AT list 整体重构（固定20行，每行=复选+输入框+HEX+Enter+发送）** —— 用户明确全新布局。
  1. 删除头部 AT 输入框/添加按钮，头部只有「config下拉(可输入) + 保存 + 一键清空」。
  2. 正文固定 ROWS=20 行 AT list，可为空但始终展示 20 行输入框（不因空而隐藏）。
  3. 每行组件：选择复选 | 输入框(可编辑) | HEX复选 | Enter复选 | 发送按钮。
  4. 首行上方「全选」总复选框：勾选=全部行勾选，去勾=全部取消（联动 _toggle_select_all）。
  5. 发送语义（_encode_row）：HEX勾选=codec.encode(HEX)；Enter勾选=ASCII+CR-LF；默认 ASCII 无后缀。发送按钮独立发送本行，与最前选择复选无关。
  6. Run：只发送勾选行（_selected_rows），循环次数=N 逐个循环；Stop 停止。
  7. 存储 configs/<name>.json 每条 = {text, hex, enter}；_collect_rows 按行号保留空行占位，保存/加载行位不被打乱；兼容旧纯字符串数组加载。
  证据：mock 全过(20行输入框/每行发送按钮/全选联动/ASCII+HEX+Enter 发送字节正确/Run只发勾选行就绪/保存加载roundtrip行位对齐)；py_compile 全过；8 回归全过。
  说明：at_hex/at_enter/at_select_all/at_clear_all 已加入 i18n(zh/en)。


- 2026-08-25：**AT list 分页版 v3（按用户 8 点需求重构）**
  1. 一键清空：清空所有输入框里的 AT 命令文本，**保留**勾选/HEX/Enter 状态（不再重建body丢勾选）。
  2. HEX/Enter 上方新增各自「全选」总复选框（HEX全选/Enter全选），联动本页；行全选依旧。
  3. 恢复序号：每行前显示 1..PAGE_SIZE。
  4. ROWS 改为 PAGE_SIZE=22。
  5. 删除滚动轮查看，改**分页**：上一页 | 页码输入框(回车跳转) | 下一页 | 添加下一页 | 第 x/n 页。
  6. 分页按"总行数(含空行)"算页数（_total_pages=ceil(len(_all_data)/22)）；默认1页22空行；「添加下一页」+22空行并跳到新页，即可操作下一页。
  7. 新增 delay time(mS)：_delay_var，Run 执行多条AT时每条间隔 delay ms（after 定时）。
  8. Run 后新增「当前轮次」显示（_round_lbl），每完成一轮递增，如 2 轮显示 第2轮。
  数据源重构：_all_data(所有页数据,含空行占位,页对齐) → _row_vars 实时 tk 变量。关键：_sync_all_from_pages 从 **_row_vars** 读实时值回写 _all_data（勿从 _pages 静态副本读，否则编辑丢失）；翻页前先 sync 旧页再改 _page（_go_prev/_go_next/_goto_page/_add_page 已处理）。
  证据：mock 全过（22行+序号1-22/行·HEX·Enter三组全选/一键清空只清txt保留勾选/分页添加下一页跳新页+回页数据保留+翻页按钮state正确/delay getter/Run 2轮=4条+轮次显示/分页保存加载roundtrip）；py_compile 全过；8 回归全过。
  i18n 新增：at_select_all_hex/at_select_all_enter/at_prev/at_next/at_add_page/at_page_goto/at_page_of/at_delay/at_round/at_no_prev/at_no_next/at_page_bad。

- 2026-08-25：**压力模式首版落地（独立于 AT 模式）+ 压测名称编辑控件** —— 进入压力模式开发。
  1. **模式切换**：`app.py`(E-SafeNet→py 字节级替换) 顶部「设置」旁新增「AT 模式/压力模式」菜单按钮（`_switch_mode`）；`_build_body` 内容包装成 `content` 容器，`at_view`(AT 视图) 与 `stress_view`(压力视图，懒加载) 同容器切换，互不销毁、各自状态保留。
  2. **独立连接**：`StressPanel` 自带独立 `SerialCore`，与 AT 模式不共享连接；打开失败弹提示，不打断 AT。`_switch_mode` 离开压力时停掉运行中的压测(不关串口)。
  3. **新模块**：`stress_io.py`(模版/导入/导出 CSV，`utf-8-sig` 双平台) + `stress_model.py`(纯逻辑：StressRow/CheckRule/预期匹配contains·regex·exact/check规则/统计/结束条件count·time/时长`0.0H`·时间段格式) + `stress_panel.py`(UI+`after` 状态机运行)。
  4. **UI**：上=串口配置(压测)+压测配置(次数/时间二选一·行间隔·响应超时·AT/DOS Log路径)；下=输出框(含DTR/RTS/清空/显示选项) | 导出模版·导入数据·导出当前数据+**压测名称(输入框+修改/保存按钮)** + 压测AT list(20行可滚动:复选·AT输入框·HEX·Enter·类型·后缀·间隔·预期结果·编辑) + 自定义check规则 + 开始/停止 + 统计块(已发送/异常/当前行/测试时长/总运行次数/脚本运行时间段)。
  5. **配置持久化**：`config.py` DEFAULT_CONFIG 新增 `stress` 段(name/end_mode/count/time/interval_ms/timeout_ms/at_log/dos_log/rows/rules)；本轮不做 GUI↔config 双向持久化（保持独立性，后续补）。
  6. **压测名称编辑**：`导出当前数据` 按钮后加名称输入框(默认禁用)+按钮(初始「修改」)；点「修改」→按钮变「保存」+输入框可编辑；点「保存」→按钮回「修改」+输入框禁用。名称写入 AT/DOS Log 头部与汇总行（对齐 P0「把压力名称写到日志」）。
  7. **验证**：`py -3.8 -m py_compile` 全过；新增 `tests/test_stress.py`(23 用例：预期匹配/规则/行模型/统计/CSV roundtrip/config·i18n·app 锚点) 全过；既有 `test_gui_regression`+`test_serial_core`(8 用例) 全过；`root.withdraw()` 离线冒烟(切模式+名称开关+收集行+预期编辑+模式往返)通过。
  说明：i18n 新增 mode_at/mode_stress/stress_* 共 40+ 键(zh/en)；app/stress_panel 因 E-SafeNet 加密，用 `py -3.8` 脚本做字节级替换后 `py_compile` 校验。

- 2026-08-26：**全项目代码走查 + 合理性修缮（E-SafeNet 下用 py 脚本字节级修改）** —— 用户要求「直接根治 + 浏览整个项目，不合理的可修复都完善」。
  1. tooltip.py：docstring 示例 `Tooltip(entry, get_text=...)` → `text=lambda: entry.get()`（对齐真实签名，避免后人踩坑）；删除从未引用的死常量 `_WRAP_ON`；`_WIDTH=560` 通过 Label `wraplength=self._WIDTH` 真正生效（原注释声称"超出自动换行"但未实现，超长路径会把悬浮小窗无限拉宽甚至超出屏幕）。
  2. i18n.py：zh 里残留的英文重复键 `dtr_rts: "Flow Pins"` 删除（保留"流控引脚"）；en 补缺失的 `dtr_rts` / `at_save_confirm`；en `at_add_page` 半中文残留 `"添加Next"` → `"Add Page"`（否则 en 用户看到 key 原文/中英混搭）。
  3. at_panel.py：行发送按钮注册 key 由伪键 `at_row_send_{idx}` 改为真实 i18n key `at_send`；否则 `_apply_language`（语言切换/初始化）会对每个注册控件 `text=self._t(key)`，而 `at_row_send_0` 在 i18n 不存在 → 22 个行发送按钮文字被覆盖成 `"at_row_send_0"`。
  4. stress_panel.py：`_poll_rx` 收到 `RX_DATA` 时补 `self._rx_last = time.monotonic()`（原只 extend 显示缓冲却未更新静默时刻，`_flush_display` 的 `RESP_IDLE_MS` 判定依赖它 → 首次靠 `_rx_last=0.0` 立即刷新、压测持续发送时又依赖发送时刻，RX 显示会滞后积压；现改为真实接收时刻驱动聚合）。
  验证：`py_compile` 全过；`unittest discover tests` 41 用例全过（含既有回归）；`import ecom.*` 全模块 OK；自写校验脚本确认 4 处修复均生效。
  说明：`stress_panel` 控件未接入 `_register` 语言刷新（切换语言时压力面板文字不随动）为已知遗留项，因需大规模改动/易回归，本轮未强行修，留待后续。
 - 2026-08-26：**压力运行日志增加「每轮开始分隔标记」** —— 用户期望按 `=================== Runtimes N ===================` 标注每一轮（而非只输出头部`=== 名称...===`与汇总）。   1. stress_panel.py 新增 `_log_round_marker(n)`：拼接 `=================== Runtimes {n} ===================`，写入输出框(`_render_note`)与 AT Log(`logger_at.log`)——与 TX/RX 落点一致，从而 header→每轮标记→汇总 完整衔接。   2. `_send_current` 入口在 `self._row_idx == 0` 时调用 `self._log_round_marker(self._rounds_done + 1)`。首轮由 `_start_run` 直达(row_idx=0)触发 Runtimes 1；后续轮由 `_advance` 将 `_row_idx` 归零进入，触发 Runtimes N(N=_rounds_done+1)。   验证：py_compile 全过；`unittest discover tests` 41 用例全过；自写离线冒烟用 mock 串口驱动 2行×2轮，marker 序列 == [Runtimes 1, Runtimes 2]（每轮仅一次、无缺失多余）。  - 2026-08-26：**运行轮次数字 disabled 灰字看不清 → 改成白色加粗** —— 点击「开始」后 `_start_run` 将 run_btn 置为 `state="disabled"`（防重复点击），ttk 按钮 disabled 默认走系统灰字，导致轮次数字（`_set_run_round` 写入 run_btn 文本）看不清。   1. stress_panel.py `_ensure_styles`：为 Run.TButton 创建 bold 字体 `self._run_font`（基于 app.ui_font copy + weight=bold）并挂到 `style.configure` 的 `font=`。   2. `style.map("Run.TButton", background=[("disabled","#1E9E4A"),("active","#17833d")], foreground=[("disabled","#ffffff"),("active","#ffffff")])`——disabled 态强制绿底白字，覆盖系统灰。   依据：app.py L116 `theme_use("clam")`，clam 完整支持自定义色与状态映射，故映射必生效（此前 Run.TButton 绿色一直正常显示即为佐证）。   验证：py_compile 全过；离线冒烟（clam 主题+AppMock）确认 weight=bold、bg/fg map 含 disabled 白绿映射、run_btn 运行态 text=3 显示正确；`unittest discover tests` 41 用例全过。  - 2026-08-26：**压测行间隔改为「AT list 行自身间隔优先，未设置回落全局行间隔」** —— 用户反馈：AT list 每行单独设置的间隔(如 3000ms)不生效，全局压测配置【行间隔(ms)】300ms 反而一直覆盖。   根因：`_advance` 调度下一行发送时直接 `interval = self.interval_var.get()`（全局），无视行自身 `interval_ms`。   修改：`_advance` 中在调度前取「即将发送的下一行」（此时 `_row_idx` 已递增/归零，恒 `0<=idx<len`）的 `interval_ms`，若 >0 则覆盖全局；=0（未单独设置）回落全局行间隔。语义：行自身间隔=发送该行前的等待。   验证：py_compile 全过；离线冒烟(捕获 _schedule_follow delay)三场景：行3000>全局300→3000；行0→回落300；行500→500；`unittest discover tests` 41 用例全过。  - 2026-08-26：**间隔语义纠偏 + AT list 默认预期 OK** —— 用户反馈两点：   1. 间隔语义偏差：设置 AT+QGMR 间隔=3000，旧实现得到「AT 执行后 3000ms 再执行 AT+QGMR」（即下一行间隔生效），用户期望该 3000 用于「AT+QGMR 自身执行后」。改法：`_advance` 取「本次刚执行完的那一行」的 interval_ms（`_row_idx` 已递增/归零：正常时=idx-1，一轮结束归零时=最后一行 len-1），>0 则覆盖全局，=0 回落。效果：AT+QGMR(3000) 执行完后等 3000 再进下一轮；AT 后到 AT+QGMR 用 AT 的间隔（未设→全局300）。   2. 每条 AT list 预期值为空→工具未对比（空预期走 has_expected=False 恒通过）。改法：stress_model.StressRow.expected 默认 "OK"（新建行默认 OK）；stress_panel._collect_rows 对勾选且非空但预期为空的行兜底补 "OK"，且不覆盖已显式设预期的行。   两处均用 py 脚本字节级替换（E-SafeNet）。验证：py_compile 全过；离线冒烟：完成AT→delay300 / 完成QGMR→delay3000；StressRow() 默认 'OK'；空预期行补 OK、已设 'READY' 行保留；`unittest discover tests` 41 用例全过。
 - 2026-08-26：**压力模式实现中英切换（补齐此前「切换语言压力面板不随动」遗留项）** —— 诊断：i18n zh/en 的 `stress_*` key 全部齐全（各 171 个且内容键集一致），压力面板控件构建时都用 `self._t(key)`（语言正确），但**未登记到 `app._text_widgets`**，导致 `app._apply_language` 只刷新 AT 主界面、不刷新压力面板。
   1. **stress_panel.py（30 处字节级替换）**：给全部静态文本控件（名称/串口/压测配置/输出/统计/IO 条/AT list/Pager/规则表头与 Pager/run box/end 区等 LabelFrame·Label·Button·Checkbutton·Radiobutton）在创建处调用 `self.app._register(key, widget)`，从而被 `_apply_language` 自动重刷。
   2. **`_build_grid_header`/`_build_rules_editor` 表头重构**：`header_texts`（翻译后字符串数组）改为 `header_keys`（key 数组，非空才登记），第 0/9 列（序号/编辑列）与规则表空列不登记，可精确刷新。
   3. **新增 `StressPanel._refresh_language()`**（处理刻意**不登记**的动态控件）：open_btn 按 `core.is_open` 显 打开/关闭；name_btn 按编辑态显 修改/保存；run_btn 非运行态显 开始、运行态保持轮次数字；并重算 `_update_run_info/_update_pager/_update_rules_pager`，最后 `_render_page()` 重建当前页行（刷新行内"编辑/序号"等，数据取自 `_rows` 不丢）。
   4. **app.py（2 处）**：`_apply_language` 的 isinstance 判定加入 `ttk.Radiobutton`（否则登记后的 Radiobutton 不刷新）；`_apply_language` 末尾调用 `getattr(self,"stress_view",None)._refresh_language()`（lazy 创建前为 None 则跳过）。
   证据：py_compile 全过；端到端冒烟（zh→en→zh 往返）静态 18+ 控件与 Radiobutton(TRadiobutton) 全部随语言刷新、open_btn/name_btn/run_btn 动态正确、编辑态/关端口态 bounce 正确；新增回归测试 `test_language_switch_updates_stress_panel`（落入 tests/test_fixes_verify.py）。`unittest discover tests` 42 用例：41 过，仅**既有** `test_file_panel_layout`（file_panel 按钮 1px 度量对齐，与本次无关）失败。说明：默认语言逻辑本身正确（config.py 默认 `"language":"zh"`、app.py `or "zh"`）；此前会话所见 `config default language: en` 只是磁盘持久化 config 的旧值。 
 - 2026-08-26：**界面配色全面优化（可一键回退）** —— 用户要求「把配色优化建议全部实现，做好回退准备」。基于真实调色板 + WCAG 对比度实测 + 2025/26 现代配色趋势（功能性色角色/支持色须与品牌色 HSB 协调/限制色阶数）做全套修改（E-SafeNet 下 py 脚本字节级替换，改前已快照）。
   新调色板(app.py P)：primary #3B6FE0→#0B57D0(白字6.39/底色5.80)、primary_h→#0842A0；muted #6B7688→#59657A(底色5.34)；success #22A06B→#15803D、danger #E5533D→#B3261E；新增 success_h #146C33、danger_h #8E1E18；tx #7FC1FF→#0B57D0、rx #9BE3A4→#15803D；全部达 WCAG AA。
   1. A1 恢复TX/RX着色：output.tag tx→P.tx蓝、rx→P.rx绿（替代原统一黑，可分发送/接收）。
   2. A2+B3 统一绿红：at/stress 的 Run.TButton→P.success、Stop.TButton→P.danger，active/disabled→success_h/danger_h（白字AA，disabled 态走更暗）。
   3. B1/B2 muted 与主蓝加深（见 P）。
   4. C2 输入/输出框加描边：ScrolledText=flat+bw0+highlightthickness1+highlightbg/color=border（可见读域边界）。
   5. C1 文件进度条：fill #90EE90→P.success，新增 _pc(key,default) helper。
   6. C3 白卡内标签底色贴合：新增 MutedSurface.TLabel(bg=surface)；app(串口field/monitor)与stress(卡片/表头/rules)的白卡标签改用它；灰条/状态栏/at_panel/file_panel 保持 Muted.TLabel。
   7. C5 tooltip：#FFFDF5/#333 → #FFFFFF/#1B2733。
   验证：py_compile 18模块全过；unittest discover tests 42用例全过；端到端构建无异常、P键含 success_h/danger_h。
   回退：快照 xbak/color_20260826_193203/（含 restore.py/restore.bat 一键还原 app/at/stress/file/tooltip 5 文件）。

 - 2026-08-26：**串口热插拔检测（设备被移除自动断开并恢复“打开串口”）** —— 用户反馈：打开串口后按钮显示“关闭串口”，但拔出 USB 后仍保持连接态、发送无返回、按钮不恢复。
   根因：USB 拔出未必让 pyserial 读线程抛出 RX_ERROR/RX_CLOSED（部分驱动下设备残留，in_waiting 不报错），且即使抛出，旧 `_poll_rx` 也只设 status_error、未真正 close 串口；`_update_status` 依赖 `core.is_open`，而异常后 `_ser.is_open` 仍为 True，按钮无法复位。
   方案：两层失效检测 + 主动断开。
   1. **端口存在性周期探测**：`app.py` 打开时记录 `self._active_port`，在 `_poll_rx`(40ms) 内每 15 次(≈600ms)调 `_check_port_presence()`——用 `list_ports.comports()` 比对当前端口是否仍在系统串口列表；不在则 `_on_port_lost()`。虚拟端口(loop:// 含 ":")跳过探测，避免自测误断开。
   2. **读线程失效接管**：`RX_ERROR`/`RX_CLOSED` 路由到 `_on_port_lost()`（原先只弹错误/刷状态），真正 `core.close()`。
   3. `_on_port_lost`：关串口 + 清 active_port + flush_rx + 输入区提示 + `_set_status_error(port_lost)`（点红·状态栏报错·open_btn→“打开串口”）+ `_refresh_ports(flash=False)`（下拉框剔除失效端口，不再闪“刷新OK”干扰）。
   4. `stress_panel.py` 同样的独立 SerialCore 也同步加固（其 open/close 按钮、`_poll_rx` 相同的断开/探测），保证压力面板端口被拔同样恢复“打开串口”。
   5. i18n zh/en 各新增 `port_lost`（设备已断开（串口被移除），已自动关闭连接 / Device disconnected (port removed), closed automatically）。
   验证：py_compile 全过；新增 tests/test_hotplug.py 5 用例（虚拟端口跳过/端口消失断开/端口仍在不断开/RX_ERROR断开/RX_CLOSED断开）全过；`unittest discover tests` 47 用例全过。

 - 2026-08-26：**压测 导出模版/导入数据/导出当前数据 格式升级（CSV+TXT+XLSX）** —— 用户反馈：现 CSV 用 Excel 打开无下拉框、index 列意义不大、希望支持 csv 和 txt。
   明确方案：①A1 ②B1 ③C1 —— 模板导出真 .xlsx（带 Excel 下拉框）；txt=CSV 换扩展名；send_type 下拉单选。
   1. **stress_io.py 重写**：
      - 去掉展示用 index 列，HEADERS 改 9 列：enabled/at/send_type/send_suffix/hex/enter/interval_ms/expected/match_mode；
      - 新增 .xlsx 读写（openpyxl）：`_write_xlsx`/`_read_xlsx`/`_add_dropdowns`，模板用 openpyxl 给 enabled·send_type·send_suffix·hex·enter·match_mode 6 列加 DataValidation 下拉（应用到 2..2000 行）；
      - `export_template`：.xlsx→带下拉框模板；.csv/.txt→逗号分隔模板；`export_data`：按扩展名 .xlsx→xlsx 数据 / .csv/.txt→csv；`import_data`：按扩展名路由 csv/txt/xlsx；
      - 兼容旧 10 列（含 index 首列）：`_offset(header)` 依据表头首列文字是否 `index` 自动 +1，读旧文件不坏。
   2. **stress_panel.py**：`_export_template` 默认 `stress_template.xlsx`（filetypes 含 Excel/CSV/TXT）；`_import_data` filetypes 含 数据文件(*.csv *.txt *.xlsx)/CSV/TXT/Excel；`_export_data` 默认 `stress_data.csv`（filetypes CSV/TXT/Excel，可改 .txt/.xlsx）。
   3. **pyproject.toml**：dependencies 新增 `openpyxl>=3.0`（此前刻意「运行时仅 pyserial+Tk」的原则性变更，用户已拍板接受）。开发机 python389 已 `pip install openpyxl 3.1.5`。
   4. **tests/test_stress.py**：BOM 导入测试数据改 9 列（去 index）；新增 `test_data_export_txt_roundtrip` / `test_xlsx_template_has_dropdowns`（断言无 index 表头+send_type/suffix/match_mode 下拉在 C/D/I）/ `test_import_xlsx_data_roundtrip`。
   验证：py_compile 全过；`unittest discover tests` 50 用例全过（47 既有 + 3 新增）；真实导出模板验证：表头无 index、6 个下拉框(type=list)选项值正确（ASCII,HEX,DEC,BIN 等）。
   说明：openpyxl 为纯 Python，pip 即装；stress_io.py 内 openpyxl 在函数内按需 import，未装时 xlsx 导出返回 False（报错提示），csv/txt 不受影响。
- 2026-08-28：**Linux 串口排障手册 + 工具入口**（用户拍板「全按推荐实现」；结合 ModemManager 抢占 AT 口根因）。
  1. **新增 `docs/TROUBLESHOOT_zh.md` / `docs/TROUBLESHOOT_en.md`**：通用 Linux 串口排障手册（现象/根因/方案一 udev `ID_MM_DEVICE_IGNORE` 永久忽略/方案二 stop ModemManager 临时/其它坑：dialout 权限、UUCP 锁、E-SafeNet 密文、CDC-ACM 波特率摆设）+ 快速判断。
  2. **新增 `ecom/help_viewer.py`**：内嵌 Tk 只读查看器，自实现 md 子集解析（#/##/###/列表/引用/```代码块/**加粗**/内联`code`），只读可选可复制（右键菜单+Ctrl+A/C，拦截非 Ctrl 键入）。
  3. **`ecom/app.py`**：顶部新增「帮助」按钮 + `help_menu`（入口 Linux 串口排障手册）；`_open_help_guide()` 按当前语言打开查看器；新增 `_mm_holds_port(port)`（POSIX 下 `fuser -v` 检测 ModemManager 占用，非 POSIX 恒 False）；成功打开与打开失败两条路径均触发 `help_mm_hint` 提示。
  4. **`ecom/i18n.py`**：zh/en 新增 `menu_help`/`help_guide`/`help_close`/`help_mm_hint` 4 词条。
  验证：py_compile 全过（app/i18n/help_viewer 及全部模块）；`unittest discover` 66/66 全过无回归；Tk 冒烟：doc_path 解析正确、md 渲染含 ModemManager/方案一、app 导入正常。备份于 `xbak/help_20260828/`（app.py.bak、i18n.py.bak）。
- 2026-08-28：**「关于」对话框 + `ecom help` 子命令 + 厂商关键字全量清除**。
  1. **①「关于」**：`ecom/app.py` 设置菜单新增「关于」项 → `_open_about()` 弹窗（标题/版本`__version__`/简介 + 「打开排障手册」Primary 按钮 + 关闭）；`i18n.py` 增 `menu_about/about_desc/about_open_guide`（zh/en）。
  2. **② `ecom help`**：`ecom/cli.py` 子命令 `help`（`choices` 加 `help`；新增 `--lang/-l` zh|en，默认 zh），终端直接打印排障手册，**不依赖 tkinter**（无显示也能用）；`_md_to_text()` 简易 md→文本转换。
  3. **厂商关键字清除**（用户要求"不要提及任何厂商"，先判断对工具运行影响：均为纯展示文档/字符串，逻辑不读取，**零运行影响**）：`docs/TROUBLESHOOT_zh/en.md` 删目标厂商名→"蜂窝模组"、删 厂商 USB VID→`<idVendor>:<idProduct>`、udev 例子用 `<VID>/<PID>` 占位；`docs/USER_GUIDE_zh/en.md` 示例串 设备全名→"USB Serial Port"；`docs/ui_mockup.html` `module.bin` 归一。`ecom/serial_core.py` 注释、`tests/test_hotplug.py` 测试替身中的厂商名亦全清（纯注释/测试替身，零运行影响），`__pycache__` 旧 .pyc 烘焙串同步删除重建。
  验证：vendor 扫描 md/html **零残留**；全包 py_compile 过；`unittest discover` 66/66 全过；`ecom help -l zh` 终端实测打印正常；实机构造 EcomApp + `_open_about()` 弹窗成功打开（title=关于）。Linux 明文包已重新导出至 `linux_patch_20260828/`（含 cli.py、清理后 docs）。
