# eCOM Windows 本机发布手册（PyPI）

> 适用场景：在**当前 Windows 机器**（文件被 E-SafeNet 加密）上完成打包并上传 PyPI，**无需 Linux**。
> 本文档是唯一操作依据；按顺序执行即可完成发布。

---

## 1. 关键结论（先读）

| 项 | 值 |
|---|---|
| 发行名（`pip install` 用） | `ecom-serial-tool` |
| 命令名 / 模块名 | `ecom`（不变） |
| 当前版本 | `0.1.0` |
| 上传产物（2 个） | `dist\\ecom_serial_tool-0.1.0.tar.gz`、`dist\\ecom_serial_tool-0.1.0-py3-none-any.whl` |
| Python 依赖 | `pyserial>=3.5`、`openpyxl>=3.0` |
| 系统级依赖 | `tkinter`（pip 装不了，Linux 需 `sudo apt install python3-tk`） |
| 构建工具 | `setuptools>=61`、`wheel`、`build`、`twine` |

> ⚠️ **`ecom` 这个名字在 PyPI 上已被他人占用**（一个 ecommerce 电商框架，作者 Ronak Patel，v1.1.1）。
> 所以发行名必须用唯一的一份 `ecom-serial-tool`，否则 `pip install ecom` 会装到别人的包。命令名与模块名 `ecom` 不受影响。

> ⚠️ **必须用 `E:\software\python389\python.exe` 构建**，且加 `--no-isolation`。该 Python 是唯一能对 E-SafeNet 密文源文件透明解密的解释器。用普通 `python -m build` 会把**密文**打进 wheel，发布后用户 `import ecom` 直接报错。

---

## 2. 项目目录结构（发布相关）

项目根目录：`E:\software\quecagent\workspaces\EdisonCode\projects\eCOM`

```
projects/eCOM/
├─ main.py              # 开发入口：python main.py 弹 GUI（不参与 wheel，仅开发用）
├─ pyproject.toml       # 【核心】打包元数据 + 入口 + 依赖 + package-data
├─ README.md            # 包 readme，会渲染到 PyPI 项目页
├─ requirements.txt     # 开发依赖说明（pyserial）
├─ run.bat              # Windows 启动快捷方式（开发用）
├─ UI_DESIGN.md         # UI 说明
├─ PROGRESS.md          # 项目进度（开发用，不参与 wheel）
├─ configs/             # 示例 AT 命令配置（*.json，用户数据，不打包进 wheel）
│  ├─ config.json
│  └─ config1.json
├─ docs/                # 说明文档目录（含本文）
│  ├─ API_REFERENCE_{zh,en}.md
│  ├─ KNOWN_ISSUES_{zh,en}.md
│  ├─ PROJECT_OVERVIEW_{zh,en}.md
│  ├─ USER_GUIDE_{zh,en}.md
│  ├─ TROUBLESHOOT_{zh,en}.md      # 排障手册「源」文档
│  ├─ ui_mockup.html
│  └─ PUBLISH_WIN.md               # 【新增】本文件
├─ ecom/                # 【真正的 Python 包，wheel 只会打进这里】
│  ├─ __init__.py       # __version__ = "0.1.0"
│  ├─ app.py            # GUI 主窗口，提供 run()
│  ├─ cli.py            # 命令行入口 main()：ecom start / help / --version
│  ├─ help_viewer.py    # 排障手册查看器，doc_path() 定位手册
│  ├─ config.py         # 配置读写（~/.ecom/config.json）
│  ├─ serial_core.py    # 串口核心
│  ├─ codec.py / i18n.py / logger.py / file_panel.py
│  ├─ at_panel.py / stress_io.py / stress_model.py / stress_panel.py
│  ├─ tooltip.py
│  └─ docs/             # 【新增】打进 wheel 的手册副本
│     ├─ TROUBLESHOT_zh.md
│     └─ TROUBLESHOT_en.md
├─ tests/               # 测试（66 个）
├─ scripts/             # install_deps.sh
├─ dist/                # 【构建产物，上传对象】只在上传前存在
│  ├─ ecom_serial_tool-0.1.0.tar.gz
│  └─ ecom_serial_tool-0.1.0-py3-none-any.whl
└─ (tools/ xbak/ export_patch/ *.zip *.bmp *.xlsx 等为历史/临时产物，不参与发布)
```

**说明**
- 打包范围由 `pyproject.toml` 的 `[tool.setuptools.packages.find] include = ["ecom*"]` 决定，**只会打进 `ecom/` 这个包**；`dist`、`tests`、`docs`、`configs`、各 `.bak`/`__pycache__` 等不会进 wheel。
- `ecom/docs/` 是**新增**，用 `[tool.setuptools.package-data] ecom = ["docs/*.md"]` 声明，才会随 wheel 一起分发。

---

## 3. 发布需要新增/改动的文件

### 3.1 必需新增文件（2 类）

**(A) 包内手册副本**：`ecom/docs/TROUBLESHOT_zh.md`、`ecom/docs/TROUBLESHOT_en.md`
- 用途：作为包内数据打进 wheel，供 `ecom help` 和 GUI「帮助 → Linux 串口排障手册」读取。
- 内容来源：与顶层 `docs/TROUBLESHOT_{zh,en}.md` 内容一致。
- 生成方式（在本加密环境，顶层 docs 是**占位文件、无法直接读取**，必须从明文 zip 流式写入，见 §3.3）；若在能正常读 docs 的机器上，直接拷贝即可。

**(B) 本手册**：`docs/PUBLISH_WIN.md`。

### 3.2 源码改动（已完成，只需知道）

| 文件 | 改动 |
|---|---|
| `pyproject.toml` | `name = "ecom-serial-tool"`、`version = "0.1.0"`、`authors`、`[project.scripts] ecom = "ecom.cli:main"`、`[tool.setuptools.package-data] ecom = ["docs/*.md"]`（完整内容见 §5） |
| `ecom/help_viewer.py` | `doc_path()` 由 `os.path.dirname(__file__)/../docs` 改为 `os.path.dirname(__file__)/docs`（指向包内） |
| `ecom/cli.py` | `_help()` 同样改为 `os.path.dirname(__file__)/docs` |

### 3.3 手册副本生成命令（本加密环境下）

只有在 `ecom/docs/` 里没有手册、或需要重建时才执行。用 PowerShell + .NET 从明文 zip 的**流**写入（绕过占位文件，得到能被 python389 读取的明文）：

```powershell
$src = 'E:\software\quecagent\workspaces\EdisonCode\projects\eCOM\ecom_plain_src.zip'
$dst = 'E:\software\quecagent\workspaces\EdisonCode\projects\eCOM\ecom\docs'
Add-Type -AssemblyName System.IO.Compression.FileSystem
New-Item -ItemType Directory -Force -Path $dst | Out-Null
$zip = [System.IO.Compression.ZipFile]::OpenRead($src)
foreach ($name in @('docs/TROUBLESHOT_zh.md','docs/TROUBLESHOT_en.md')) {
  $e = $zip.GetEntry($name); $in = $e.Open()
  $out = [System.IO.File]::Create((Join-Path $dst ($name -replace 'docs/','')))
  $in.CopyTo($out); $out.Close(); $in.Close()
}
$zip.Dispose()
```

> 若 `ecom_plain_src.zip` 已不存在或内容过期，可先用 python389 从解密源重新打一个明文 zip（见 §11）。

---

## 4. 前置条件（需要哪些因素）

1. **PyPI 账号**已注册（发布到 TestPyPI 用同账号）。
2. **PyPI API Token**：到 `https://pypi.org/manage/account/token/` 生成（只显示一次，妥善保存，勿公开）。
3. **本机 `E:\software\python389\python.exe`**（E-SafeNet 解密 Python）——打包和上传都建议用它。
4. **构建工具**：`setuptools>=61`、`wheel`、`build`、`twine`（首次会自动装，命令见 §6）。
5. **发行名唯一**：`ecom-serial-tool` 已在 pypi.org 验证空闲。
6. **版本号唯一**：PyPI 相同 (发行名, 版本) 只能存在一份，重复上传会被拒。
7. **网络**：本机能访问 `pypi.org`。
8. **Token 保密**：不要写进任何文件/仓库/截图。

---

## 5. `pyproject.toml` 完整内容（以此为准）

```toml
[build-system]
requires = ["setuptools>=61.0", "wheel"]
build-backend = "setuptools.build_meta"

[project]
name = "ecom-serial-tool"
version = "0.1.0"
description = "跨平台轻量级串口调试工具（Windows + Linux）"
readme = "README.md"
requires-python = ">=3.8"
license = { text = "MIT" }
authors = [{ name = "EDISON" }]
dependencies = [
    "pyserial>=3.5",
    "openpyxl>=3.0",
]

[project.scripts]
ecom = "ecom.cli:main"

[tool.setuptools.packages.find]
include = ["ecom*"]

[tool.setuptools.package-data]
ecom = ["docs/*.md"]
```

**各字段含义**
- `name`：发布到 PyPI 的**发行名**，全局唯一，用 `ecom-serial-tool`。
- `version`：版本号；**每次重新发布前必须递增**（如 `0.1.1`）。
- `requires-python`：最低 Python 版本，`>=3.8`。
- `dependencies`：安装时自动拉取的第三方库。
- `[project.scripts]`：装完包后生成的**命令** `ecom` = 调用 `ecom.cli:main`。
- `[tool.setuptools.package-data]`：额外把 `ecom/docs/*.md` 一起打进包。

---

## 6. 打包命令（Windows，python389 + --no-isolation）

在**同一个 cmd 窗口**执行：

```bat
cd /d E:\software\quecagent\workspaces\EdisonCode\projects\eCOM

:: 1) 首次或换机器：安装构建工具（已装过会提示 already satisfied）
"E:\software\python389\python.exe" -m pip install --upgrade setuptools wheel build twine

:: 2) 先清理旧的 dist（避免残留旧版本文件）
if exist dist rmdir /s /q dist

:: 3) 构建 sdist + wheel
::    关键：--no-isolation，让 setuptools 在 python389 进程内读取“解密后”的明文源码
"E:\software\python389\python.exe" -m build --no-isolation

:: 4) 校验（应输出两行 PASSED；任何 WARNING/ERROR 都要先处理）
"E:\software\python389\python.exe" -m twine check dist\*
```

**结果**：`dist\` 下生成 2 个文件——
- `ecom_serial_tool-<version>.tar.gz`（源码包）
- `ecom_serial_tool-<version>-py3-none-any.whl`（平台无关 wheel）

---

## 7. 上传命令（Windows）

在**同一个 cmd 窗口**（环境变量只在当前会话有效，务与 `set`、`twine upload` 连着执行）：

```bat
:: 用 Token（账号名写死 __token__，密码填 token），不要用账号密码
set TWINE_USERNAME=__token__
set TWINE_PASSWORD=pypi-你的API_TOKEN

:: 上传整个 dist（会同时上传 sdist 和 wheel）
"E:\software\python389\python.exe" -m twine upload "E:\software\quecagent\workspaces\EdisonCode\projects\eCOM\dist\*"
```

> 也可改用 `--repository-url https://upload.pypi.org/legacy/` 显式指定（默认即 PyPI）。
> 想先试水不想公开，把 URL 换成 TestPyPI：`--repository-url https://test.pypi.org/legacy/`，并另发一个测试 token。

---

## 8. 上传哪些文件（就是 dist/ 下那 2 个）

| 文件 | 说明 |
|---|---|
| `ecom_serial_tool-0.1.0.tar.gz` | sdist 源码包 |
| `ecom_serial_tool-0.1.0-py3-none-any.whl` | 平台无关 wheel（py3 = Python3，none-any = 跨平台） |

**不要上传**：`dist/` 之外的一切（源码、`docs/`、`configs/`、`tests/`、`*.zip`、`.bak`、`__pycache__`）。wheel + sdist 已包含运行所需全部内容（含手册）。

---

## 9. 发布后验证（本机）

```bat
:: 重新安装 / 升级
"E:\software\python389\python.exe" -m pip install --upgrade ecom-serial-tool

ecom --version        :: 应输出 ecom 0.1.0
ecom start            :: 应弹出 GUI（Linux 需先 sudo apt install python3-tk）
ecom help             :: 应打印 Linux 串口排障手册（说明手册已进包）
```

> 刚发布后 `pip install` 可能命中 PyPI CDN 缓存，稍等 1–2 分钟再试，或用 `--no-cache-dir`。

---

## 10. 常见的坑

1. **版本重复**：同名同版本只能传一次 → 报 `File already exists`。解决：改 `version` 后重跑 §6、§7。
2. **普通 python 构建出密文**：忘加 `--no-isolation` 或没走 python389 → wheel 里的 `.py` 是乱码。解决：严格按 §6 命令。
3. **被 E-SafeNet 加密的文件传了**：不要从加密树直接 `zip` 源文件；改用 §3.3 的流式写入，或仅在 `dist/` 层级操作。
4. **Token 泄露**：只放在本会话环境变量，切勿提交仓库/截图。
5. **tkinter 缺失**：不是 pip 依赖，Linux 要用系统包管理装。
6. **PyPI 页面 readme 不渲染**：把 `README.md` 用 `readme = "README.md"` 指定（已配置）。

---

## 11. 重建明文源码包 `ecom_plain_src.zip`（仅在需要传给无加密机器/重打手册时）

本环境下用 python389 从解密源重新打一个**明文** zip（注意：顶层 docs/ 的参考文档是占位文件，python389 读不到，可能无法完整纳入；不影响构建与发布）：

```python
# 用 python389 运行：打包 ecom/、pyproject.toml、README.md、main.py、requirements.txt、run.bat、configs/、tests/、scripts/
import zipfile, os
base = r'E:\software\quecagent\workspaces\EdisonCode\projects\eCOM'
out = os.path.join(base, 'ecom_plain_src.zip')
targets = ['pyproject.toml','README.md','main.py','requirements.txt','run.bat','UI_DESIGN.md','configs','ecom','tests','scripts']
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
    for t in targets:
        p = os.path.join(base, t)
        if os.path.isfile(p):
            z.write(p, t)
        elif os.path.isdir(p):
            for root, _, fs in os.walk(p):
                for f in fs:
                    rp = os.path.join(root, f)
                    arc = os.path.relpath(rp, base)
                    z.write(rp, arc)
print('done', out)
```

---

## 12. 回滚 / 下线

- PyPI **一般不允许直接删除**已发布版本；若上传出错，可到项目页对该版本点 **Yank**（设为不再被默认安装），或发布新版本覆盖。
- 换名/换版本均在 `pyproject.toml` 改即可，其余流程不变。
